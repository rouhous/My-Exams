# My Exams | اختباراتي

An independent English exam-practice **review build** for Omani Grades 5–12. It is independent of English-Foundation / My English Journey.

## Publishing

1. Create a **public** GitHub repository named `My-Exams` in the `rouhous` account (do not add initial README or .gitignore).
2. Upload the complete contents of this package to the repository root (keep the `grade9/`, `grades5-6/`, `grades7-8/`, `.github/`, and `scripts/` directories intact).
3. Open Settings > Pages > Build and deployment and select **GitHub Actions**.
4. Open Actions > Publish My Exams Preview > Run workflow if it did not run automatically.
5. Your preview address is `https://rouhous.github.io/My-Exams/` once deployment succeeds.

## Current known limitations

- The root page is a **curriculum/audio review interface**, not yet a final student production portal.
- The 38 locally referenced MP3s for Grades 5–9 are **provisional synthetic** audio. No locally stored natural speech recordings are present.
- The source download workflow is experimental and may fail if externally hosted audio links are unavailable.
- Full curriculum alignment, Grades 10–12 media, offline behavior, and device QA need finishing before sharing with students.
- Do not commit secrets, authentication tokens, or private student data.

See `README_AR.md`, `INTEGRITY_REPORT.json`, `AUDIO_STATUS.csv`, and `UNIT_ACTIVITY_QA.csv` for detailed status.
